/*FOLLOW MY INSTAGRAM PRESIDEN LEADER LORD MOCH NANGG XR*/
const fs = require("fs");
const {
   indonesia
} = require("./language");

// Website Api (jgn di ganti biar gk eror)
global.APIs = {
   alfa: 'https://api.zeeoneofc.my.id', //apabila link api eror, segera laporkan ke owner
}

//buy apikey premium 62895414128194
// Free apikey (silahkan login terus ganti Your Key dgn apikey lu)
global.APIKeys = {
   'https://api.zeeoneofc.my.id': '6T8nj4b9zYHBlyL', // 👉 free apikey from irulz limit 30 !! 
}

//language 
global.language = indonesia //change indonesia to english if you don't understand the language used by the bot

global.BOT_TOKEN = "1234567890:IYAHH999XWkkvSJffpRUNFwtQMj8FqORFyp4" // buat bot di sini https://t.me/Botfather dan dapatkan token bot
global.BOT_NAME = "𝐏𝐑𝐄𝐒𝐈𝐃𝐄𝐍 𝐋𝐄𝐀𝐃𝐄𝐑 𝐋𝐎𝐑𝐃 𝐌𝐎𝐂𝐇 𝐍𝐀𝐍𝐆𝐆 𝐗𝐑 𝐁𝐎𝐓" //your bot name
global.OWNER_NAME = "𝐏𝐑𝐄𝐒𝐈𝐃𝐄𝐍 𝐋𝐄𝐀𝐃𝐄𝐑 𝐋𝐎𝐑𝐃 𝐌𝐎𝐂𝐇 𝐍𝐀𝐍𝐆𝐆 𝐗𝐑 𝐁𝐎𝐓ོ" //your name
global.OWNER_NUMBER = "62895414128194" //your telegram number
global.OWNER = ["https://t.me/PREDIDENNANGGXR_BOT", "https://t.me/PRESIDENNANGGXR_BOT"] // pastikan username sudah sesuai agar fitur khusus owner bisa di pakai
global.THUMBNAIL = "./image/irulzthumb.jpg" // ini lol.jpg adalah nama foto di folder image. untuk foto bot
global.DONASI = "./image/donasi.jpg" // foto donasi di folder image
global.lang = language //don't change
