/*SUBSCRIBE MY YOUTUBE IRULZXD YT*/
exports.indonesia = require('./indonesia')
exports.english = require('./english')
