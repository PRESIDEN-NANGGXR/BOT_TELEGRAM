/*SUBSCRIBE MY YOUTUBE IRULZXD YT*/
exports.first_chat = "Hello"
